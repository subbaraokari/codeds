package org.geatlearning.sll;

import java.util.Scanner;

public class MainDemo {

	public static void main(String[] args) {
		int ch, data;
		Scanner sc = new Scanner(System.in);
		SingleLinkedList sll = new SingleLinkedList();
		sll.createList();
		while (true) {
			System.out.println("1.Display List");
			System.out.println("2.Insert Node");
			System.out.println("3.exit");
			System.out.println("Enter your choice");
			ch = sc.nextInt();
			if (ch == 3)
				break;
			switch (ch) {
			case 1:
				sll.displayList();
				break;
			case 2:
				System.out.println("Element the element to be inserted");
				data = sc.nextInt();
				sll.insertNodeInOrder(data);
				break;
			default:
				System.out.println("Please enter correct choice");
			}
		}
	}

}
