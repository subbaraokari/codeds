package org.geatlearning.sll;

public class Node {
	public int info;
	public Node link;
	public Node(int i)
	{
		this.info=i;
	}
}
