package org.greatlearning.juiceshop;

import java.util.Collections;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Scanner;

public class MinimumTime {
	int seconds;
	Scanner sc = new Scanner(System.in);
	PriorityQueue<Integer> queue = new PriorityQueue<>(Collections.reverseOrder());

	// get the data from user and add it to the queue
	public void getData() {
		System.out.println("Total number of orders for Mango milkshake");
		queue.add(sc.nextInt());
		System.out.println("Total number of orders for Orange milkshake");
		queue.add(sc.nextInt());
		System.out.println("Total number of orders for Pineapple milkshake");
		queue.add(sc.nextInt());
	}

	// find the minimum time required to fill the cups
	public void findMinimumTime() {
		Iterator<Integer> list = queue.iterator();
		while (!queue.isEmpty()) {
			int val1 = 0, val2 = 0;
			if (list.hasNext()) {
				val1 = queue.remove();
			}
			if (list.hasNext()) {
				val2 = queue.remove();
			}
			if (val1 == 0 && val2 > 0) {
				seconds += val2;
				break;
			}
			if (val1 > 0 && val2 == 0) {
				seconds += val1;
				break;
			}
			if (val1 > 0 && val2 > 0) {
				val1--;
				val2--;
				seconds++;
			}
			if (val1 > 0)
				queue.add(val1);
			if (val2 > 0)
				queue.add(val2);
		}
	}

	public static void main(String s[]) {
		MinimumTime minimumTime = new MinimumTime();
		minimumTime.getData();
		minimumTime.findMinimumTime();
		System.out.println("\nMinimum time needed to deliver all orders is:" + minimumTime.seconds);
	}
}
